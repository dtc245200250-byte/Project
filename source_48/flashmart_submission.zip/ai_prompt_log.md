# AI Prompt Log – FlashMart

## Prompt 1 – INNER JOIN và LEFT JOIN
Trong MySQL, JOIN mặc định là loại JOIN nào nếu không ghi INNER, LEFT hay RIGHT? Nó giữ hay loại các bản ghi không có sự trùng khớp?

## Prompt 2 – COUNT với LEFT JOIN
Khi dùng LEFT JOIN và COUNT để đếm số đơn hàng theo từng khách hàng, nên dùng COUNT(*) hay COUNT(o.order_id)? Vì sao khách hàng chưa mua phải ra 0?

## Prompt 3 – Anti-Join
Vì sao LEFT JOIN kết hợp WHERE o.order_id IS NULL có thể tìm các bản ghi không tồn tại ở bảng Orders?

## Prompt 4 – Performance
Hãy phân tích về mặt khái niệm hiệu năng giữa LEFT JOIN ... IS NULL và NOT IN khi tìm bản ghi không tồn tại trong bảng khác.

## Prompt 5 – FULL OUTER JOIN trong MySQL
MySQL không có FULL OUTER JOIN trực tiếp thì có thể kết hợp LEFT JOIN và RIGHT JOIN như thế nào để mô phỏng?
